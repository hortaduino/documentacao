/*
 
  Original Author: Lucas Ferreira da Silva https://github.com/LucasFerreiraDaSilva
  Version : 15/10/2018

*/

#ifndef HTTPAPI_ESP8266_H
#define HTTPAPI_ESP8266_H


#include <ESP8266HTTPClient.h>
#include <ArduinoJson.h>

class HttpApi_Esp8266	
{
	public:
		HttpApi_Esp8266(){;}
    
    void postStringRequest(String host, String var_name, String var_value) {

        HTTPClient http;    // Declare object of class HTTPClient

        http.begin(host);   // Specify request destination
        http.addHeader("Content-Type", "application/json"); // Specify content-type header

        String req = "{\""+var_name+"\":\""+var_value+"\"}"; // Create json string request
        Serial.println("Requisicao: "+req);
               
        int httpCode = http.POST(req);  // Send the request
        Serial.println("A requisicao retornou o codigo HTTP: "+ String(httpCode));   // Print HTTP return code 
     
        http.end();  // Close connection
	}

    void postNumberRequest(String host, String var_name, int var_value) {

        HTTPClient http;    // Declare object of class HTTPClient

        http.begin(host);   // Specify request destination
        http.addHeader("Content-Type", "application/json"); // Specify content-type header

        String req = "{\""+var_name+"\":"+String(var_value)+"}"; // Create json string request
        Serial.println("Requisicao: "+req);
        int httpCode = http.POST(req);  // Send the request
        Serial.println("A requisicao retornou o codigo HTTP: "+ String(httpCode));   // Print HTTP return code
     
        http.end();  // Close connection
     
	}

    int getNumberRequest(String host, String obj) {

        HTTPClient http;    // Declare object of class HTTPClient

        http.begin(host+obj+"/?format=json");   // Specify request destination

        int httpCode = http.GET();  // Send the request
        int valor;
        
        if (httpCode > 0) { // Check the returning code

            int bufferSize = JSON_OBJECT_SIZE(3) + 70;
            DynamicJsonBuffer jsonBuffer(bufferSize);
            JsonObject& root = jsonBuffer.parseObject(http.getString());

            //int id = root["id"];
            //const char* timestamp = root["timestamp"]; 
            valor = root["valor"]; 
        }

	Serial.println("A requisicao retornou o codigo HTTP: "+ String(httpCode));

        http.end();  // Close connection

        return valor;
    }
};

#endif
